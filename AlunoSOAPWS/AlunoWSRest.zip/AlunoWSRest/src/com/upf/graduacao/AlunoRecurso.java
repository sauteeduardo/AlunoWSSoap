package com.upf.graduacao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/carros")
public class AlunoRecurso {
	
	//BANCO FAKE
	static private HashMap<Integer, Aluno> alunosMap;
	
	static {
		Aluno Eduardo = new Aluno();
		Eduardo.setAluno("Eduardo");
		Eduardo.setId(1);
		Eduardo.setNota1(7.0);
		Eduardo.setNota2(8.0);
		Eduardo.setNota3(6.0);
		
		Aluno Joao = new Aluno();
		Joao.setAluno("Joao");
		Joao.setId(2);
		Joao.setNota1(7.0);
		Joao.setNota2(9.0);
		Joao.setNota3(10.0);
		
		alunosMap = new HashMap<Integer, Aluno>();
		alunosMap.put(Eduardo.getId(), Eduardo);
		alunosMap.put(Joao.getId(), Joao);
	}
	
	@Produces("text/xml")
	public String resultado(@PathParam("id") int id){
		Double soma;
		soma = alunosMap.get(id).getNota1() +
				alunosMap.get(id).getNota2()+
				alunosMap.get(id).getNota3();
		soma = soma/3;
		if(soma < 3.0) {
			return "Reprovado";
		}else if(soma > 3.0 && soma < 7.0) {
			return "Em exame";
		}else{
			return "Aprovado";
		}
	}
	
	@Path("{id}")
	@GET
	@Produces("text/xml")
	public Double verificaMediaFinal(@PathParam("id") int id){
		Double soma;
		soma = alunosMap.get(id).getNota1() +
				alunosMap.get(id).getNota2()+
				alunosMap.get(id).getNota3();
		soma = soma/3;
		return soma;
	}
	
	@Path("{id}")
	@DELETE
	@Produces("text/plain")
	public String removeAluno(@PathParam("id") int idAluno){//PATH PARAM
		if (alunosMap.containsKey(idAluno)){
			Aluno aluno = alunosMap.get(idAluno);
			alunosMap.remove(idAluno);
			return aluno.getAluno() + " foi exclu�do com sucesso!";
		} else {
			return "Chave inexistente!";
		}
	}
	
	@POST
	@Consumes("text/xml")
	@Produces("text/plain")
	//JAX-RS XML -> SERIALIZA - INSTANCIA DE CARRO
	public String insereAluno(Aluno aluno){
		try {
			alunosMap.put(aluno.getId(), aluno);
			return "sucesso!";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "falha " + e.getLocalizedMessage(); 
		}
	}
	
	@PUT
	@Consumes("text/xml")
	public String alteraCarro(Aluno aluno){
		if (alunosMap.containsKey(aluno.getId())){
			alunosMap.replace(aluno.getId(), aluno);
			return "Sucesso!";
		} else {
			return "Carro para altera��o n�o existe ainda!";
		}
	}
}
